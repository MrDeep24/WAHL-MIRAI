// Archivo:       pqr-manage.js
// Módulo:        M08 — Ayuda, Tutorial, PQR y Chatbot
// Desarrollador: Kevin
// Descripción:   Carga, filtra y representa tickets PQR para su gestión
//                administrativa, y controla el modal de respuesta.
//                Se integra con los endpoints de consulta y resolución.
// Requerimientos: RF-M08-02.
// PQR — Gestión y Resolución (RF-M08-02)
// Conecta el listado y el modal de respuesta con los endpoints reales
// de PqrController: GET /Pqr/List?status=, POST /Pqr/Resolve/{id}
//
// No depende de clases Tailwind específicas — usa atributos data-*
// para que funcione con cualquier estilo que tenga la vista real.
//
// Markup mínimo requerido en Manage.cshtml (agregar estos atributos
// al markup que ya existe, sin cambiar tus clases/estilos):
//
//   Tabs de filtro:
//     <button data-pqr-filter="TODAS">Todas</button>
//     <button data-pqr-filter="ABIERTO">Abiertas</button>
//     <button data-pqr-filter="RESUELTO">Resueltas</button>
//
//   Buscador:
//     <input data-pqr-search type="text" placeholder="Buscar...">
//
//   Contenedor donde se insertan las filas (reemplaza su innerHTML):
//     <div data-pqr-list></div>
//
//   Modal (oculto por defecto, ej. con la clase "hidden" de Tailwind
//   o display:none — el script solo alterna esa clase):
//     <div data-pqr-modal class="hidden"> ... </div>
//     <button data-pqr-close>X</button>          (botón X del header)
//     <button data-pqr-cancel>Cancelar</button>
//     <button data-pqr-submit>Enviar Respuesta</button>
//     <textarea data-pqr-response-input></textarea>
//     <span data-pqr-field="elector-name"></span>
//     <span data-pqr-field="elector-id"></span>
//     <span data-pqr-field="fecha"></span>
//     <span data-pqr-field="asunto"></span>
//     <span data-pqr-field="mensaje"></span>
//
//   Antiforgery token (agregar en algún lugar de la vista si no existe):
//     @Html.AntiForgeryToken()
//
//   Fila individual (generada dinámicamente por este script, pero cada
//   botón "Ver Detalle" debe llevar data-pqr-view="{id del ticket}" —
//   eso ya lo genera renderRow() más abajo, no hace falta tocarlo).
//
(function () {
  'use strict';

  const state = {
    filter: 'ABIERTO', // coincide con la pestaña activa por defecto del mockup
    search: '',
    tickets: [],
  };

  const els = {};

  function cacheEls() {
    // NOTA: la integración con el DOM (IDs/estructura esperada de la
    // vista Manage.cshtml) no se verificó en esta pasada de
    // documentación — la vista está fuera del alcance de este archivo.
    els.list = document.querySelector('[data-pqr-list]');
    els.filterButtons = document.querySelectorAll('[data-pqr-filter]');
    els.search = document.querySelector('[data-pqr-search]');
    els.modal = document.querySelector('[data-pqr-modal]');
    els.close = document.querySelector('[data-pqr-close]');
    els.cancel = document.querySelector('[data-pqr-cancel]');
    els.submit = document.querySelector('[data-pqr-submit]');
    els.responseInput = document.querySelector('[data-pqr-response-input]');
    els.fields = {
      electorName: document.querySelector('[data-pqr-field="elector-name"]'),
      electorId: document.querySelector('[data-pqr-field="elector-id"]'),
      fecha: document.querySelector('[data-pqr-field="fecha"]'),
      asunto: document.querySelector('[data-pqr-field="asunto"]'),
      mensaje: document.querySelector('[data-pqr-field="mensaje"]'),
    };
  }

  // Obtiene el token antiforgery que se envía en la resolución del ticket.
  function getCsrfToken() {
    const input = document.querySelector('input[name="__RequestVerificationToken"]');
    if (!input) {
      console.error('[PQR] No se encontró el antiforgery token. Agrega @Html.AntiForgeryToken() en la vista.');
      return null;
    }
    return input.value;
  }

  // Formatea una fecha ISO para presentarla en la interfaz en español de Colombia.
  function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // Calcula las iniciales del nombre para el avatar de la fila.
  function initials(name) {
    if (!name) return '??';
    const parts = name.trim().split(/\s+/);
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase();
  }

  // Consulta los tickets según el filtro activo y actualiza el listado.
  async function fetchTickets() {
    const params = new URLSearchParams();
    if (state.filter !== 'TODAS') params.set('status', state.filter);

    try {
      const res = await fetch(`/Pqr/List?${params.toString()}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
      });
      const data = await res.json();
      if (!data.ok) {
        console.error('[PQR] Error al listar:', data.message);
        state.tickets = [];
      } else {
        state.tickets = data.tickets || [];
      }
    } catch (err) {
      console.error('[PQR] Fallo de red al listar tickets:', err);
      state.tickets = [];
    }
    renderList();
  }

  // Filtra localmente los tickets cargados por nombre de elector o asunto.
  function filteredTickets() {
    if (!state.search) return state.tickets;
    const q = state.search.toLowerCase();
    return state.tickets.filter(
      (t) => t.userName?.toLowerCase().includes(q) || t.subject?.toLowerCase().includes(q)
    );
  }

  // Representa la lista filtrada y conecta sus botones de detalle.
  function renderList() {
    if (!els.list) return;
    const tickets = filteredTickets();

    if (tickets.length === 0) {
      els.list.innerHTML = '<p data-pqr-empty>No hay PQR para mostrar.</p>';
      return;
    }

    els.list.innerHTML = tickets.map(renderRow).join('');

    els.list.querySelectorAll('[data-pqr-view]').forEach((btn) => {
      btn.addEventListener('click', () => openModal(btn.getAttribute('data-pqr-view')));
    });
  }

  // Genera el marcado de una fila/tarjeta PQR con sus datos visibles.
  function renderRow(t) {
    const statusLabel = t.status === 'ABIERTO' ? 'Abierta' : 'Resuelta';
    const userName = t.userName || '';
    const safeName    = escapeHtml(userName);
    const safeSubject = escapeHtml(t.subject || '');
    const statusBadgeClass = t.status === 'ABIERTO'
      ? 'bg-status-pending/10 text-status-pending'
      : 'bg-status-graduated/20 text-status-graduated';

    return `
      <div data-pqr-row data-status="${t.status}"
           class="md:grid md:grid-cols-12 md:gap-2 md:items-center md:px-2 md:py-3 md:border-b md:text-sm
                  flex flex-col gap-0 rounded-lg border border-outline-variant bg-surface p-3 text-sm md:rounded-none md:border-x-0 md:border-t-0 md:bg-transparent md:p-0">

        <!-- MOBILE: avatar + name on one line; DESKTOP: col-span-1 avatar + col-span-3 name -->
        <div class="flex items-center gap-2 md:contents">
          <div class="md:col-span-1 md:flex md:items-center shrink-0">
            <span data-pqr-avatar
                  class="w-8 h-8 rounded-full bg-primary-container text-on-primary-container flex items-center justify-center text-xs font-semibold"
                  aria-hidden="true">
              ${initials(userName)}
            </span>
          </div>
          <span data-pqr-col="elector"
                class="font-medium text-on-surface md:col-span-3 md:truncate md:font-normal"
                aria-label="Votante: ${safeName}">
            ${safeName}
          </span>
        </div>

        <!-- MOBILE: subject on its own line; DESKTOP: col-span-4 with truncate -->
        <p data-pqr-col="asunto"
           class="mt-1 text-on-surface-variant md:mt-0 md:col-span-4 md:truncate md:text-on-surface"
           aria-label="Asunto: ${safeSubject}">
          ${safeSubject}
        </p>

        <!-- MOBILE: badge + button on one line; DESKTOP: col-span-2 + col-span-2 -->
        <div class="flex items-center gap-2 mt-2 md:mt-0 md:contents">
          <span data-pqr-col="estado"
                data-status-value="${t.status}"
                class="md:col-span-2"
                aria-label="Estado: ${escapeHtml(statusLabel)}">
            <span class="inline-block px-2 py-1 rounded-full text-xs font-medium ${statusBadgeClass}">
              ${statusLabel}
            </span>
          </span>
          <div class="md:col-span-2">
            <button data-pqr-view="${t.id}"
                    class="px-3 py-2 min-h-[44px] min-w-[44px] rounded-lg bg-primary text-on-primary text-xs font-medium hover:opacity-90 transition-opacity flex items-center justify-center"
                    aria-label="Ver detalle de PQR: ${safeSubject}">
              Ver Detalle
            </button>
          </div>
        </div>

      </div>
    `;
  }

  // Escapa texto antes de incluir datos del ticket dentro del marcado generado.
  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // Carga el detalle del ticket seleccionado y abre el modal de respuesta.
  function openModal(ticketId) {
    const ticket = state.tickets.find((t) => String(t.id) === String(ticketId));
    if (!ticket || !els.modal) return;

    els.modal.dataset.currentTicketId = ticket.id;
    els.fields.electorName.textContent = ticket.userName || '';
    els.fields.electorId.textContent = `ID: ${ticket.userId}`;
    els.fields.fecha.textContent = formatDate(ticket.createdAt);
    els.fields.asunto.textContent = ticket.subject || '';
    els.fields.mensaje.textContent = ticket.message || '';

    if (ticket.status === 'RESUELTO') {
      els.responseInput.value = ticket.adminResponse || '';
      els.responseInput.disabled = true;
      els.submit.disabled = true;
      els.submit.textContent = 'Ya resuelta';
    } else {
      els.responseInput.value = '';
      els.responseInput.disabled = false;
      els.submit.disabled = false;
      els.submit.textContent = 'Enviar Respuesta';
    }

    els.modal.classList.remove('hidden');
  }

  // Cierra el modal y elimina el identificador del ticket activo.
  function closeModal() {
    if (!els.modal) return;
    els.modal.classList.add('hidden');
    delete els.modal.dataset.currentTicketId;
  }

  // Valida y envía la respuesta administrativa, luego actualiza el listado.
  async function submitResponse() {
    const ticketId = els.modal?.dataset.currentTicketId;
    const adminResponse = els.responseInput?.value?.trim();

    if (!ticketId) return;
    if (!adminResponse) {
      alert('Escribe una respuesta antes de enviar.');
      return;
    }

    const token = getCsrfToken();
    if (!token) {
      alert('No se pudo verificar el token de seguridad. Recarga la página.');
      return;
    }

    els.submit.disabled = true;
    els.submit.textContent = 'Enviando...';

    try {
      const res = await fetch(`/Pqr/Resolve/${ticketId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          RequestVerificationToken: token,
        },
        body: JSON.stringify({ adminResponse }),
      });
      const data = await res.json();

      if (!data.ok) {
        alert(data.message || 'No se pudo enviar la respuesta.');
        els.submit.disabled = false;
        els.submit.textContent = 'Enviar Respuesta';
        return;
      }

      closeModal();
      await fetchTickets(); // refresca la lista para reflejar el nuevo estado
    } catch (err) {
      console.error('[PQR] Fallo de red al resolver ticket:', err);
      alert('Error de red. Intenta de nuevo.');
      els.submit.disabled = false;
      els.submit.textContent = 'Enviar Respuesta';
    }
  }

  // Sincroniza el estilo visual de los filtros con su atributo data-active.
  function updateFilterStyles() {
    els.filterButtons.forEach((b) => {
      const isActive = b.getAttribute('data-active') === 'true';
      if (isActive) {
        b.classList.add('bg-primary', 'text-on-primary');
        b.classList.remove('border');
      } else {
        b.classList.remove('bg-primary', 'text-on-primary');
        b.classList.add('border');
      }
    });
  }

  // Conecta filtros, búsqueda, controles del modal y envío de la respuesta.
  function bindEvents() {
    els.filterButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        state.filter = btn.getAttribute('data-pqr-filter');
        els.filterButtons.forEach((b) => b.removeAttribute('data-active'));
        btn.setAttribute('data-active', 'true');
        updateFilterStyles();
        fetchTickets();
      });
    });

    if (els.search) {
      let debounce;
      els.search.addEventListener('input', (e) => {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
          state.search = e.target.value;
          renderList();
        }, 200);
      });
    }

    els.close?.addEventListener('click', closeModal);
    els.cancel?.addEventListener('click', closeModal);
    els.submit?.addEventListener('click', submitResponse);
  }

  document.addEventListener('DOMContentLoaded', () => {
    cacheEls();
    if (!els.list) {
      console.warn('[PQR] No se encontró [data-pqr-list] — este script no aplica en esta vista.');
      return;
    }
    updateFilterStyles();
    bindEvents();
    fetchTickets();
  });
})();
